#include <stdio.h>

void main()
{
	printf("Main function:\n");
	comp1();
	comp2();
	comp3();
	comp4();
	printf("\nCompleted\n");
}
