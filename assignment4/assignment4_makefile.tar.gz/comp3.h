#ifndef COMP3_H__
#define COMP3_H__

void comp3(void);

#endif
