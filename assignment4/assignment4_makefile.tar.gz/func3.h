#ifndef FUNC3_H__
#define FUNC3_H__

void func3(void);

#endif
