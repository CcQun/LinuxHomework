#ifndef FUNC2_H__
#define FUNC2_H__

void func2(void);

#endif
