#ifndef COMP1_H__
#define COMP1_H__

void comp1(void);

#endif
