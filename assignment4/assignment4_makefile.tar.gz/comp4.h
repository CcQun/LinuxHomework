#ifndef COMP4_H__
#define COMP4_H__

void comp4(void);

#endif
