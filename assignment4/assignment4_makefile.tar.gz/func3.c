#include <stdio.h>
#include "func3.h"
#include "usedtype.h"

void func3(void)
{
	STR s;
	s.info="this is Func3";
	printf("%s", s.info);
}
