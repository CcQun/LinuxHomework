#ifndef COMP2_H__
#define COMP2_H__

void comp2(void);

#endif
