#ifndef FUNC1_H__
#define FUNC1_H__

void func1(void);

#endif
