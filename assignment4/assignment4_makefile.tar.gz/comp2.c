#include "func2.h"

void comp2(void)
{
	func2();
	func2();
}
