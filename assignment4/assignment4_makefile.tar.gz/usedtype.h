#ifndef USEDTYPE_H__
#define USEDTYPE_H__

#include <string.h>
typedef struct {
	char *info;
}STR;

#endif
